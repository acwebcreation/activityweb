#!/usr/bin/env python3
"""Guide PDF (FR / EN / DE) de la carte à gratter de Saint-Nicolas — ActivityWeb Studio
Usage : python3 guide_carte_a_gratter.py --lien "https://mes-applis-96z.pages.dev/carte-saint-nicolas-k4m2pz/"
"""
import argparse, os, random
from reportlab.pdfgen import canvas
from reportlab.lib.pagesizes import A4
from reportlab.lib.units import mm
from reportlab.lib.colors import HexColor, Color
from reportlab.pdfbase import pdfmetrics
from reportlab.pdfbase.ttfonts import TTFont
from reportlab.graphics.barcode import qr
from reportlab.graphics.shapes import Drawing
from reportlab.graphics import renderPDF

FONTS = os.path.join(os.path.dirname(os.path.abspath(__file__)), "fonts")
for n, f in [("Corm", "Cormorant-Medium.ttf"), ("CormI", "Cormorant-Italic.ttf"),
             ("Play", "Playfair-SemiBold.ttf"), ("PlayI", "Playfair-Italic.ttf")]:
    pdfmetrics.registerFont(TTFont(n, os.path.join(FONTS, f)))

NUIT, NUIT2 = HexColor("#16203A"), HexColor("#34466F")
OR, OR_CLAIR = HexColor("#C9A66B"), HexColor("#E8D3A2")
ROUGE, CREME, TEXTE, GRIS = HexColor("#7E222B"), HexColor("#FFF8F0"), HexColor("#2A2440"), HexColor("#6B6377")

T = {
    "fr": dict(
        titre="Votre carte à gratter", sous="de Saint-Nicolas",
        intro="Merci pour votre achat ! Voici comment créer votre carte et l’envoyer en quelques minutes.",
        lien_titre="Votre accès à l’outil", qr="Scannez pour l’ouvrir sur votre téléphone",
        lien_note="Ajoutez ce lien à vos favoris. Il vous est réservé : merci de ne pas le partager.",
        etapes_titre="Créer et envoyer votre carte",
        etapes=[
            ("Ouvrez l’outil", "Cliquez sur le lien ci-dessus ou scannez le QR code."),
            ("Écrivez votre surprise", "Choisissez une idée toute prête ou écrivez votre message : prénom, phrase d’introduction, message caché, et une grande zone ou trois cases à gratter."),
            ("Choisissez un style", "Nuit étoilée, Mitre rouge et or, ou Spéculoos."),
            ("Testez, puis créez le lien", "Touchez « Voir l’aperçu » pour gratter vous-même, puis « Créer le lien »."),
            ("Envoyez", "Touchez « Envoyer sur WhatsApp », ou « Copier » pour l’envoyer par SMS, e-mail ou Messenger."),
        ],
        astuces_titre="Bon à savoir",
        astuces=["La personne qui reçoit la carte n’a rien à installer : elle ouvre le lien et gratte avec le doigt.",
                 "Si vous modifiez la carte après avoir créé le lien, créez un nouveau lien.",
                 "Pour garder la surprise, envoyez le lien le matin du 6 décembre."],
        contact="Une question ? Écrivez-nous via la messagerie Etsy ou en répondant à votre reçu de paiement."),
    "en": dict(
        titre="Your scratch card", sous="for Saint Nicholas Day",
        intro="Thank you for your purchase! Here’s how to create your card and send it in just a few minutes.",
        lien_titre="Your access to the tool", qr="Scan to open it on your phone",
        lien_note="Bookmark this link. It’s for you only, so please don’t share it.",
        etapes_titre="Create and send your card",
        etapes=[
            ("Open the tool", "Click the link above or scan the QR code."),
            ("Write your surprise", "Pick a ready-made idea or write your own message: name, opening line, hidden message, and one big area or three circles to scratch."),
            ("Choose a style", "Starry Night, red and gold Mitre, or Speculoos."),
            ("Test it, then create the link", "Tap “Preview” to try scratching it yourself, then “Create link”."),
            ("Send it", "Tap “Send on WhatsApp”, or “Copy” to send it by text, email or Messenger."),
        ],
        astuces_titre="Good to know",
        astuces=["The recipient doesn’t need to install anything: they open the link and scratch with a finger.",
                 "If you change the card after creating the link, create a new link.",
                 "To keep the surprise, send the link on the morning of December 6."],
        contact="Any questions? Message us on Etsy or reply to your payment receipt."),
    "de": dict(
        titre="Ihre Nikolaus-", sous="Rubbelkarte",
        intro="Vielen Dank für Ihren Kauf! So erstellen und verschicken Sie Ihre Karte in wenigen Minuten.",
        lien_titre="Ihr Zugang zum Tool", qr="Scannen, um es auf dem Handy zu öffnen",
        lien_note="Speichern Sie diesen Link als Lesezeichen. Er ist nur für Sie bestimmt: Bitte nicht weitergeben.",
        etapes_titre="Karte erstellen und verschicken",
        etapes=[
            ("Tool öffnen", "Klicken Sie auf den Link oben oder scannen Sie den QR-Code."),
            ("Überraschung schreiben", "Wählen Sie eine fertige Idee oder schreiben Sie Ihre Nachricht: Vorname, Einleitungssatz, versteckte Nachricht und ein großes Feld oder drei Kreise zum Rubbeln."),
            ("Stil wählen", "Sternennacht, Mitra in Rot und Gold oder Spekulatius."),
            ("Testen und Link erstellen", "Tippen Sie auf „Vorschau“, um selbst zu rubbeln, dann auf „Link erstellen“."),
            ("Verschicken", "Tippen Sie auf „Per WhatsApp senden“ oder auf „Kopieren“ für SMS, E-Mail oder Messenger."),
        ],
        astuces_titre="Gut zu wissen",
        astuces=["Die beschenkte Person muss nichts installieren: Sie öffnet den Link und rubbelt mit dem Finger.",
                 "Wenn Sie die Karte nach dem Erstellen des Links ändern, erstellen Sie einen neuen Link.",
                 "Damit die Überraschung gelingt, schicken Sie den Link am Morgen des 6. Dezember."],
        contact="Fragen? Schreiben Sie uns über Etsy oder antworten Sie auf Ihre Zahlungsbestätigung."),
}


def lignes(txt, font, size, largeur):
    mots, out, cur = txt.split(), [], ""
    for m in mots:
        t = (cur + " " + m).strip()
        if pdfmetrics.stringWidth(t, font, size) <= largeur:
            cur = t
        else:
            out.append(cur); cur = m
    if cur: out.append(cur)
    return out


def etoile(c, x, y, r, col):
    p = c.beginPath()
    for k in range(8):
        import math
        a = math.pi / 2 + k * math.pi / 4
        rr = r if k % 2 == 0 else r * 0.3
        (p.moveTo if k == 0 else p.lineTo)(x + rr * math.cos(a), y + rr * math.sin(a))
    p.close(); c.setFillColor(col); c.drawPath(p, stroke=0, fill=1)


def page(c, L, lien):
    W, H = A4
    M = 20 * mm
    c.setFillColor(CREME); c.rect(0, 0, W, H, stroke=0, fill=1)
    # bandeau
    bh = 62 * mm
    c.saveState()
    p = c.beginPath(); p.rect(0, H - bh, W, bh); c.clipPath(p, stroke=0)
    c.linearGradient(0, H, 0, H - bh, (NUIT, NUIT2), extend=True)
    r = random.Random(4)
    for _ in range(70):
        c.setFillColor(Color(.95, .88, .7, alpha=.3 + r.random() * .6))
        c.circle(r.random() * W, H - bh + r.random() * bh, .3 + r.random() * .9, stroke=0, fill=1)
    for _ in range(9):
        etoile(c, r.random() * W, H - bh + 8 * mm + r.random() * (bh - 12 * mm), 2 + r.random() * 2.5, OR_CLAIR)
    c.restoreState()
    c.setFillColor(OR_CLAIR); c.setFont("PlayI", 15); c.drawString(M, H - 20 * mm, "ActivityWeb Studio")
    c.setFillColor(CREME); c.setFont("Play", 30); c.drawString(M, H - 35 * mm, L["titre"])
    c.setFillColor(OR); c.setFont("PlayI", 26); c.drawString(M, H - 47 * mm, L["sous"])
    # intro
    y = H - bh - 12 * mm
    c.setFillColor(TEXTE)
    for ln in lignes(L["intro"], "Corm", 14, W - 2 * M):
        c.setFont("Corm", 14); c.drawString(M, y, ln); y -= 6.2 * mm
    # encadré lien
    y -= 4 * mm
    bx_h = 44 * mm
    c.setFillColor(HexColor("#FFFFFF")); c.setStrokeColor(OR); c.setLineWidth(1.4)
    c.roundRect(M, y - bx_h, W - 2 * M, bx_h, 4 * mm, stroke=1, fill=1)
    qs = 34 * mm
    w = qr.QrCodeWidget(lien); b = w.getBounds()
    d = Drawing(qs, qs, transform=[qs / (b[2] - b[0]), 0, 0, qs / (b[3] - b[1]), 0, 0]); d.add(w)
    qx = W - M - qs - 7 * mm
    renderPDF.draw(d, c, qx, y - bx_h + 8.5 * mm)
    cap = lignes(L["qr"], "CormI", 9, qs + 6 * mm)
    cy = y - bx_h + 5.2 * mm
    for ln in cap[:2]:
        c.setFillColor(GRIS); c.setFont("CormI", 9); c.drawCentredString(qx + qs / 2, cy, ln); cy -= 3.6 * mm
    tx, tw = M + 7 * mm, qx - M - 14 * mm
    ty = y - 11 * mm
    c.setFillColor(ROUGE); c.setFont("Play", 15); c.drawString(tx, ty, L["lien_titre"])
    ty -= 9 * mm
    fs = 11.5
    while pdfmetrics.stringWidth(lien, "Corm", fs) > tw and fs > 7.5: fs -= .5
    c.setFillColor(HexColor("#1E4FA0")); c.setFont("Corm", fs); c.drawString(tx, ty, lien)
    lw = pdfmetrics.stringWidth(lien, "Corm", fs)
    c.linkURL(lien, (tx, ty - 2, tx + lw, ty + fs), relative=0)
    c.setStrokeColor(HexColor("#1E4FA0")); c.setLineWidth(.5); c.line(tx, ty - 1.5, tx + lw, ty - 1.5)
    ty -= 8 * mm
    c.setFillColor(GRIS)
    for ln in lignes(L["lien_note"], "CormI", 11.5, tw):
        c.setFont("CormI", 11.5); c.drawString(tx, ty, ln); ty -= 5 * mm
    y -= bx_h + 11 * mm
    # étapes
    c.setFillColor(TEXTE); c.setFont("Play", 17); c.drawString(M, y, L["etapes_titre"])
    y -= 10 * mm
    for i, (t, d_) in enumerate(L["etapes"], 1):
        c.setFillColor(OR); c.circle(M + 4.5 * mm, y + 1.4 * mm, 4.5 * mm, stroke=0, fill=1)
        c.setFillColor(NUIT); c.setFont("Play", 13); c.drawCentredString(M + 4.5 * mm, y - .3 * mm, str(i))
        c.setFillColor(TEXTE); c.setFont("Play", 12.5); c.drawString(M + 13 * mm, y + .5 * mm, t)
        yy = y - 5.6 * mm
        for ln in lignes(d_, "Corm", 12.5, W - 2 * M - 13 * mm):
            c.setFillColor(GRIS); c.setFont("Corm", 12.5); c.drawString(M + 13 * mm, yy, ln); yy -= 5.2 * mm
        y = yy - 4 * mm
    # bon à savoir
    y -= 2 * mm
    c.setFillColor(ROUGE); c.setFont("Play", 14); c.drawString(M, y, L["astuces_titre"])
    y -= 7.5 * mm
    for a in L["astuces"]:
        etoile(c, M + 2 * mm, y + 1.3 * mm, 2.2, OR)
        for k, ln in enumerate(lignes(a, "Corm", 12.5, W - 2 * M - 8 * mm)):
            c.setFillColor(TEXTE); c.setFont("Corm", 12.5); c.drawString(M + 7 * mm, y, ln); y -= 5.2 * mm
        y -= 1.5 * mm
    # pied
    c.setStrokeColor(OR); c.setLineWidth(.6); c.line(M, 18 * mm, W - M, 18 * mm)
    c.setFillColor(GRIS); c.setFont("CormI", 11); c.drawCentredString(W / 2, 12 * mm, L["contact"])


if __name__ == "__main__":
    ap = argparse.ArgumentParser()
    ap.add_argument("--lien", required=True)
    ap.add_argument("--out", default="Guide_carte_a_gratter_Saint-Nicolas.pdf")
    a = ap.parse_args()
    c = canvas.Canvas(a.out, pagesize=A4)
    c.setTitle("Carte à gratter de Saint-Nicolas — Guide")
    c.setAuthor("ActivityWeb Studio")
    for lg in ("fr", "en", "de"):
        page(c, T[lg], a.lien); c.showPage()
    c.save()
    print("OK :", a.out)
